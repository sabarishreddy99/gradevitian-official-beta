// -------------------------------Comments js file----------------------------

function comment(){

};